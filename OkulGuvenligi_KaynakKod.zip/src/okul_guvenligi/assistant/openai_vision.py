from __future__ import annotations

import json
import os
import socket
import urllib.error
import urllib.request
from typing import Any

from ..core.models import ChangePlan
from .schema import PLAN_TOOL, SYSTEM_INSTRUCTIONS


class OpenAIUnavailable(RuntimeError):
    pass


class OpenAIVisionPlanner:
    """OpenAI Responses API istemcisi. Anahtar yalnız sunucu prosesinde tutulur."""

    API_URL = "https://api.openai.com/v1/responses"
    MAX_IMAGE_DATA_URL_CHARS = 10 * 1024 * 1024

    def __init__(self, *, api_key: str | None = None, model: str | None = None, timeout: int = 45):
        self.api_key = (api_key if api_key is not None else os.environ.get("OPENAI_API_KEY", "")).strip()
        self.model = (model if model is not None else os.environ.get("LOGOS_OPENAI_MODEL", "gpt-5.6")).strip() or "gpt-5.6"
        self.timeout = max(10, min(int(timeout), 120))

    @property
    def configured(self) -> bool:
        return bool(self.api_key)

    def status(self) -> dict[str, Any]:
        return {"configured": self.configured, "model": self.model, "vision": True, "mode": "openai" if self.configured else "local-fallback"}

    @staticmethod
    def _screen_context_text(screen_context: dict[str, Any] | None) -> str:
        if not screen_context:
            return "Ekran bağlamı verilmedi."
        safe = {
            "current_view": str(screen_context.get("current_view", ""))[:80],
            "current_module": str(screen_context.get("current_module", ""))[:120],
            "module_fields": [str(x)[:80] for x in (screen_context.get("module_fields") or [])[:60]],
            "module_actions": [str(x)[:80] for x in (screen_context.get("module_actions") or [])[:30]],
            "visible_columns": [str(x)[:80] for x in (screen_context.get("visible_columns") or [])[:80]],
        }
        return "LOGOS ekran bağlamı: " + json.dumps(safe, ensure_ascii=False)

    def _payload(self, message: str, image_data_url: str = "", screen_context: dict[str, Any] | None = None) -> dict[str, Any]:
        content: list[dict[str, Any]] = [
            {"type": "input_text", "text": self._screen_context_text(screen_context) + "\n\nKullanıcı isteği: " + message.strip()}
        ]
        if image_data_url:
            if len(image_data_url) > self.MAX_IMAGE_DATA_URL_CHARS:
                raise ValueError("Asistan görseli çok büyük. Daha küçük bir ekran görüntüsü yükleyin.")
            if not image_data_url.startswith(("data:image/png;base64,", "data:image/jpeg;base64,", "data:image/webp;base64,")):
                raise ValueError("Asistan görseli PNG, JPG veya WEBP olmalıdır.")
            content.append({"type": "input_image", "image_url": image_data_url, "detail": "auto"})
        return {
            "model": self.model,
            "instructions": SYSTEM_INSTRUCTIONS,
            "input": [{"role": "user", "content": content}],
            "tools": [PLAN_TOOL],
            "tool_choice": {"type": "function", "name": "propose_logos_plan"},
            "parallel_tool_calls": False,
        }

    @staticmethod
    def _parse_plan(response: dict[str, Any], *, vision_used: bool) -> ChangePlan:
        for item in response.get("output", []) if isinstance(response, dict) else []:
            if isinstance(item, dict) and item.get("type") == "function_call" and item.get("name") == "propose_logos_plan":
                args = item.get("arguments", "{}")
                if isinstance(args, str):
                    args = json.loads(args)
                return ChangePlan.from_dict(args, source="openai", vision_used=vision_used)
        raise OpenAIUnavailable("OpenAI güvenli plan aracı çağrısı döndürmedi.")

    def plan(self, message: str, *, image_data_url: str = "", screen_context: dict[str, Any] | None = None) -> ChangePlan:
        if not self.configured:
            raise OpenAIUnavailable("OpenAI bağlantısı yapılandırılmamış.")
        payload = json.dumps(self._payload(message, image_data_url, screen_context), ensure_ascii=False).encode("utf-8")
        request = urllib.request.Request(
            self.API_URL,
            data=payload,
            method="POST",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "LOGOS-TECH-Vision/5.0",
            },
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                raw = response.read()
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")[:1000]
            raise OpenAIUnavailable(f"OpenAI isteği başarısız ({exc.code}). {detail}") from exc
        except (urllib.error.URLError, TimeoutError, socket.timeout) as exc:
            raise OpenAIUnavailable("OpenAI bağlantısına ulaşılamadı. Yerel güvenli asistan kullanılabilir.") from exc
        try:
            parsed = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise OpenAIUnavailable("OpenAI yanıtı okunamadı.") from exc
        return self._parse_plan(parsed, vision_used=bool(image_data_url))
